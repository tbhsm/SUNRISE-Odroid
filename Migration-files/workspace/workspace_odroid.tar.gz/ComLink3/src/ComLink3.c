/*
 ============================================================================
 Name        : ComLink3.c
 Author      : Palinecko
 Version     :
 Copyright   : Free stuff
 Description : Hello World in C, Ansi-style
 ============================================================================
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <errno.h>
#include <inttypes.h>
#include <modbus.h>

#include "readDatabase.h"

/*DEFINE SOME USEFUL STUFF*/
#define LOOP             1
#define SERVER_ID        0 /*used to be 17*/
#define ADDRESS_START    771
#define ADDRESS_END      782

int main(void) {
	readData();
	/*getchar();*/
	writeData();
//	getchar();
	readData();
//	getchar();
	puts("!!!Hello welcome in Matrix. You did a wise choice with the blue pill!!!"); /* prints !!!Hello Future!!! */
	modbus_t *ctx;
	/*Memory management stuff variables*/
	 uint16_t *tab_rq_registers;
	 uint16_t *tab_rw_rq_registers;
	 uint16_t *tab_rp_registers;
	 /*useful variables for register manipulation*/

	 int nb;
	 int rc;
	 int addr;
	 int slave;

	/*TCP Connection*/
	ctx = modbus_new_tcp("192.168.1.186",502);
	modbus_set_debug(ctx,TRUE);
	slave = modbus_set_slave(ctx,0);

	if (modbus_connect(ctx) == -1){
		fprintf(stderr,"Connection Failed %s \n",modbus_strerror(errno));
		modbus_free(ctx);
	return -1;
	}

	/*After the we have connection allocate some memory*/
	    nb = ADDRESS_START;

	    tab_rq_registers = (uint16_t *) malloc(nb * sizeof(uint16_t));
	    memset(tab_rq_registers, 0, nb * sizeof(uint16_t));

	    tab_rp_registers = (uint16_t *) malloc(nb * sizeof(uint16_t));
	    memset(tab_rp_registers, 0, nb * sizeof(uint16_t));

	    tab_rw_rq_registers = (uint16_t *) malloc(nb * sizeof(uint16_t));
	    memset(tab_rw_rq_registers, 0, nb * sizeof(uint16_t));



	    addr=ADDRESS_START;

	        /*Some random numbers to the memory for fun*/
	        int i;
	        for (i=0; i<nb; i++) {
	                    tab_rq_registers[i] = (uint16_t) (65535.0*rand() / (RAND_MAX + 1.0));
	                    tab_rw_rq_registers[i] = ~tab_rq_registers[i];

	                }

	        /*Now try to read something*/
	        rc = modbus_read_registers(ctx,addr,10,tab_rp_registers);
	        if (rc != 10){
	          printf("ERROR : did not read properly") ;
	          printf("Messed up on address : %d\n",addr);
	        }
	        else {
	            for (i=0; i<10; i++) {
	            printf("%" PRIu16 "\n",tab_rp_registers[i]);}}
	        getchar();

	        /*Lets try to save the data*/
	        FILE *fp;
	        fp = fopen("READREGISTERS.txt","w+");
	        for (i=0;i<10;i++){
	        fprintf(fp, "%s %d %s %" PRIu16 "\r\n", "Register", addr+i, "has", tab_rp_registers[i]);
	        }
	        fclose(fp);

	        /*Create binary file as well*/
	        FILE *fh = fopen ("file.bin", "wb");
	        if (fh != NULL) {
	            for (i=0;i<10;i++){
	            fwrite (&tab_rp_registers[i], sizeof (tab_rp_registers[i]), 1, fh);}
	            fclose (fh);
	        }

	        /*lets try to read the all out of it*/
	        fh = fopen ("file.bin", "rb");
	        if (fh != NULL) {
	            for(i=0;i<10;i++){
	            fread (&tab_rp_registers[i], sizeof (tab_rp_registers[i]), 1, fh);}
	            fclose (fh);
	        }

	        /* Check that it worked */
	        for (i=0;i<10;i++){
	        printf("%s %d %s %" PRIu16 "\r\n", "Register", addr+i, "has", tab_rp_registers[i]);
	        }
	        getchar();

	        /* Free the memory */
	        free(tab_rq_registers);
	        free(tab_rp_registers);
	        free(tab_rw_rq_registers);

	        /* Close the connection */
	        modbus_close(ctx);
	        modbus_free(ctx);

	return EXIT_SUCCESS;
}
