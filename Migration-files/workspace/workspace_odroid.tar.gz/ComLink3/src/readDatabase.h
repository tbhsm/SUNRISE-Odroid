/*
 * readDatabase.h
 *
 *  Created on: Sep 28, 2015
 *      Author: odroid
 */

#ifndef READDATABASE_H_
#define READDATABASE_H_

#include <mysql.h>
#include <stdio.h>
#include <stdlib.h>

void readData();
void writeData();

#endif /* READDATABASE_H_ */
